import { User } from '../user/user';

export class Login {
  public loginStatus: boolean;
  public user: User;
}
