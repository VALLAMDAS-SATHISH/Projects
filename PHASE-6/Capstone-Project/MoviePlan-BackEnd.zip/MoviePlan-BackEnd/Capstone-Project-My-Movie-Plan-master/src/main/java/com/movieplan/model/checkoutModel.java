package com.movieplan.model;

public class checkoutModel {

}
