package com.ecommerce;
import java.math.BigDecimal;


import java.util.Date;

public class Entity {

        private long ID;
        private String name;
        private String Email;
        private String Feedback;
        private Date dateAdded;
		public long getID() {
			return ID;
		}
		public void setID(long iD) {
			ID = iD;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getEmail() {
			return Email;
		}
		public void setEmail(String email) {
			Email = email;
		}
		public String getFeedback() {
			return Feedback;
		}
		public void setFeedback(String feedback) {
			Feedback = feedback;
		}
		public Date getDateAdded() {
			return dateAdded;
		}
		public void setDateAdded(Date dateAdded) {
			this.dateAdded = dateAdded;
		}  
        
        
}
