package com.ecommerce;



import java.sql.ResultSet;    


import java.sql.SQLException;    
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;    
import org.springframework.jdbc.core.JdbcTemplate;    
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;     
//use autowire this UserDao object to main controller
@Repository
public class UserDAO {

		@Autowired
        JdbcTemplate template;    
        
        
        //setter method
        public void setTemplate(JdbcTemplate template) {    
            this.template = template;    
        }    
        
        public List<Entity> getFeedback(){    
            return template.query("select * from feedback",new RowMapper<Entity>(){    
                public Entity mapRow(ResultSet rs, int row) throws SQLException {    
                	Entity e=new Entity();    
                    e.setID(rs.getLong(1));    
                    e.setName(rs.getString(2));
                    e.setEmail(rs.getString(3));
                    e.setFeedback(rs.getString(4));  
                    e.setDateAdded(rs.getDate(5));    
                    return e;    
                }    
            });    
        }  
        
        public int GiveFeedback(Entity feedbacks)
        {
        	return template.update("INSERT INTO feedback (ID, name, Email,Feedback,date_added) VALUES(?,?,?,?,?)",
        	        new Object[] { feedbacks.getID(),feedbacks.getName(),feedbacks.getEmail(),feedbacks.getFeedback(),feedbacks.getDateAdded()});
        }

		public Entity getByName(String string) {
			// TODO Auto-generated method stub
			return null;
		}
        
        
}