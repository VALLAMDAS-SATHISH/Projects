package com.simplilearn.demo;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class AmazonLogin {
  
	WebDriver driver=null;
	
	@Test
	public void welcome() {
		
		System.out.println("Welcome to Amazon Automation Test");
		
	}
	
	@BeforeMethod
	public void beforeMethod() {
		
		System.out.println("Before Method");
		/// Step-1 : Declare path of driver
		 String path= "C:\\SATHISH\\chromedriver\\chromedriver.exe";
	     System.setProperty("webdriver.chrome.driver",path);
		driver = new ChromeDriver();
		driver.get("https://www.amazon.in/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.in%2Fyour-account%3Fref_%3Dnav_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=inflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&");
		
		 WebElement email= driver.findElement(By.id("ap_email"));
	        email.getAttribute("placeholder");
	        
	        System.out.println(email.getAttribute("placeholder"));
	        email.sendKeys("sathish123@gmail.com");
	        WebElement login1= driver.findElement(By.id("continue"));
	        login1.click();
	        
	        WebElement password= driver.findElement(By.id("ap_password"));
	        password.getAttribute("placeholder");
	        
	        System.out.println(password.getAttribute("placeholder"));
	        
	        
	         
	        password.sendKeys("sathish@123cool");
	         
	        WebElement login= driver.findElement(By.id("signInSubmit"));
	        login.click();
	}
	
	
	
}