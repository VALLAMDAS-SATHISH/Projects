package com.register;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login {
	
	public static void main(String[] args) throws IOException,InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\\\SATHISH\\\\chromedriver\\\\chromedriver.exe");
		
		
		
		;
		
		WebDriver driver= new ChromeDriver();
		driver.get("https://www.shine.com/myshine/login/");
		driver.manage().window().maximize();
		
		WebElement email= driver.findElement(By.id("id_email_login"));
        email.getAttribute("placeholder");
        
        System.out.println(email.getAttribute("placeholder"));
        
        WebElement password= driver.findElement(By.id("id_password"));
        password.getAttribute("placeholder");
        
        System.out.println(password.getAttribute("placeholder"));
        
        email.sendKeys("vsathish0@gmail.com");
         
        password.sendKeys("cool@1234");
         
        WebElement login= driver.findElement(By.id("loginContainer"));
        login.click();
		

}
}
