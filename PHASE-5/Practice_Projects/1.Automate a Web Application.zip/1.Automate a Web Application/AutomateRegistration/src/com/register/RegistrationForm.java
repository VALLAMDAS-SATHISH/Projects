package com.register;



	import java.io.IOException;

	import org.openqa.selenium.By;
	import org.openqa.selenium.JavascriptExecutor;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;

	public class RegistrationForm {

		
		public static void main(String[] args) throws IOException,InterruptedException {
			System.setProperty("webdriver.chrome.driver","C:\\\\SATHISH\\\\chromedriver\\\\chromedriver.exe");
			
			
			WebDriver driver= new ChromeDriver();
			driver.get("https://www.shine.com/registration/");
			driver.manage().window().maximize();
			
			
			WebElement name= driver.findElement(By.id("id_name"));
			name.sendKeys("Sathish");
			 WebElement check= driver.findElement(By.id("id_privacy"));
		        
		       
		        
		        WebElement email= driver.findElement(By.id("id_email"));
		        email.sendKeys("vsathish0@gmail.com");
		        
		        WebElement pass= driver.findElement(By.id("id_password"));
		        pass.sendKeys("Cool@1234");
		        
		        WebElement mobile= driver.findElement(By.id("id_cell_phone"));
		        mobile.sendKeys("9885131080");
		        
		        WebElement button= driver.findElement(By.id("registerButton"));
		        button.click();
		         
			
			WebElement element= driver.findElement(By.id("id_file"));
			JavascriptExecutor executor =(JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click()", element);
			
				Thread.sleep(5000);
				Runtime.getRuntime().exec("C:\\Users\\hp\\Desktop\\SIMPLELEARN\\PHASE-5\\screenshot\\upload.exe");
			 				
				
		}
	}
