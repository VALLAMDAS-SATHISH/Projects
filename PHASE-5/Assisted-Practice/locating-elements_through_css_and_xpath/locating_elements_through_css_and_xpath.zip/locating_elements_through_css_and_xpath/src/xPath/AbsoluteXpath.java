package xPath;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AbsoluteXpath {

	public static void main(String[] args) {
		
		String path= "C:\\SATHISH\\chromedriver\\chromedriver.exe";
	     System.setProperty("webdriver.chrome.driver",path);
		
	     WebDriver driver= new ChromeDriver();
			///step:2 base url
	     driver.get("https://www.amazon.in/");
			
			driver.manage().window().maximize();
			
			/*
			 Using Xpath as a Locator
			 Absolute XPath
			 Syntax : html/body/div[1]/div[1]/div/h4[1]/b
			*/
			
			driver.findElement(By.xpath("html/body/div[1]/div[1]/div/h4[1]/b"));


	}

}
