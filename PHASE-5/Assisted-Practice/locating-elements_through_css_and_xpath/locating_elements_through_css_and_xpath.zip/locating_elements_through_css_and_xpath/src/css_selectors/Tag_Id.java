package css_selectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Tag_Id {

	public static void main(String[] args) {
		
		String path= "C:\\SATHISH\\chromedriver\\chromedriver.exe";
	     System.setProperty("webdriver.chrome.driver",path);
		
	     WebDriver driver= new ChromeDriver();
			///step:2 base url
	     driver.get("https://www.amazon.in/");
			
			driver.manage().window().maximize();
			
			/*
			 Using Path as a CSS Selector
			 Tag and ID
			 Syntax: �css = tag#id�
			*/
			
			driver.findElement(By.cssSelector("input#email"));


	}

}
