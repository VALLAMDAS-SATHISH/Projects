package com.ecommerce;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Upload {
	
	public static void main(String[] args) throws IOException,InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\\\SATHISH\\\\chromedriver\\\\chromedriver.exe");
		
		
		WebDriver driver= new ChromeDriver();
		driver.get("https://www.shine.com/registration/");
		
		
		WebElement name= driver.findElement(By.id("id_name"));
		name.sendKeys("Sathish");
		 WebElement check= driver.findElement(By.id("id_privacy"));
	         
		
		WebElement element= driver.findElement(By.id("id_file"));
		JavascriptExecutor executor =(JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click()", element);
		
			Thread.sleep(5000);
			Runtime.getRuntime().exec("C:\\Users\\hp\\Desktop\\SIMPLELEARN\\PHASE-5\\screenshot\\upload.exe");
		 
			
			
	}
}



