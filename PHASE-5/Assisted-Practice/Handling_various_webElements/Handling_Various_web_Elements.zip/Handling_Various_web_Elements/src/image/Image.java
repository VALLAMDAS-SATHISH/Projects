package image;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class Image {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 String path= "C:\\SATHISH\\chromedriver\\chromedriver.exe";
	     System.setProperty("webdriver.chrome.driver",path);
		
	     WebDriver driver= new ChromeDriver();
		driver.get("https://www.amazon.in/");

		//Below code will locate the images.
		driver.findElement(By.xpath("//a[@id='nav-logo-sprites']"));

		System.out.println("Found successfully");
		
	}

}
