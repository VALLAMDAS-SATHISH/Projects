package radioButton;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class SelectionCheck {


	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 String path= "C:\\SATHISH\\chromedriver\\chromedriver.exe";
	     System.setProperty("webdriver.chrome.driver",path);
		
	     WebDriver driver= new ChromeDriver();
	     driver.get("http://www.calculator.net/mortgage-payoff-calculator.html");
		
		//Puts an Implicit wait, Will wait for 10 seconds before throwing exception
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
	    driver.findElement(By.id("cpayoff1")).click();
	    System.out.println("The Output of the IsSelected " +
	            driver.findElement(By.id("cpayoff1")).isSelected());
	}

}