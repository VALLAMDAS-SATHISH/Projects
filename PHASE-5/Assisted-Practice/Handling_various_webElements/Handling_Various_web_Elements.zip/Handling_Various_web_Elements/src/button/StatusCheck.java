package button;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class StatusCheck {

	public static void main(String[] args) {
		

		 String path= "C:\\SATHISH\\chromedriver\\chromedriver.exe";
	     System.setProperty("webdriver.chrome.driver",path);
		
	     WebDriver driver= new ChromeDriver();
		driver.get("https://www.lambdatest.com/");
		
		WebElement a = driver.findElement(By.linkText("Login"));
		System.out.println(a.isEnabled());
	}

}
