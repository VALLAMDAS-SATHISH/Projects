package externalPopUps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class Popups {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 String path= "C:\\SATHISH\\chromedriver\\chromedriver.exe";
	     System.setProperty("webdriver.chrome.driver",path);
		//To click on �OK� button in pop up
	     WebDriver driver = new ChromeDriver();
		driver.switchTo().alert().accept();
		
		//To click on �Cancel� button in pop up
		WebDriver driver1 = new ChromeDriver();
		driver.switchTo().alert().dismiss();
		
		//To Capure the alert message
		 WebDriver driver2 = new ChromeDriver();
				driver.switchTo().alert().getText();

		//To enter the information
				WebDriver driver3 = new ChromeDriver();
				driver.switchTo().alert().sendKeys("text");
		
		//To exit from the popup
		WebDriver driver4 = new ChromeDriver();
		((WebDriver) driver.switchTo().alert()).close();

	}

}
