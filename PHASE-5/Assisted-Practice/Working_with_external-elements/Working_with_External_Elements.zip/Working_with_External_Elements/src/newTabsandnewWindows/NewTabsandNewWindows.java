package newTabsandnewWindows;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class NewTabsandNewWindows {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String path= "C:\\SATHISH\\chromedriver\\chromedriver.exe";
	     System.setProperty("webdriver.chrome.driver",path);
		//Opening new tab
	     WebDriver driver = new ChromeDriver();
			driver.findElement(By.id("xyz")).sendKeys(Keys.CONTROL + "t");
		
		//Opening new Window
			 WebDriver driver1 = new ChromeDriver();
				driver1.findElement(By.id("xyz")).sendKeys(Keys.CONTROL + "w");
		 
	}

}
