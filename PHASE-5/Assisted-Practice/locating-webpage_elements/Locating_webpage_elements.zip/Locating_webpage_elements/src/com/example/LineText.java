package com.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LineText {

	public static void main(String[] args) {
	
		
		String path= "C:\\SATHISH\\chromedriver\\chromedriver.exe";
	     System.setProperty("webdriver.chrome.driver",path);
		
	     WebDriver driver= new ChromeDriver();
			///step:2 base url
	     driver.get("https://www.amazon.in/");
			
			driver.manage().window().maximize();
			/*
			 Using LinkText as a Locator
			 Finding  Web element using Locator Link Text
			 Syntax : link =  partialLink  of the element
			*/
			
			driver.findElement(By.partialLinkText("plink"));
		

	}

}
