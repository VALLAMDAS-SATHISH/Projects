package com.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ClassName {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String path= "C:\\SATHISH\\chromedriver\\chromedriver.exe";
	     System.setProperty("webdriver.chrome.driver",path);
		
	     WebDriver driver= new ChromeDriver();
			///step:2 base url
	     driver.get("https://www.amazon.in/");
			
			driver.manage().window().maximize();
		/*
		Using class name as a Locator
		Finding  Web element using Locator ClassName
		Syntax : class = Class Name of the element
		*/
		
		driver.findElement(By.className("classname"));
	
	}

}

