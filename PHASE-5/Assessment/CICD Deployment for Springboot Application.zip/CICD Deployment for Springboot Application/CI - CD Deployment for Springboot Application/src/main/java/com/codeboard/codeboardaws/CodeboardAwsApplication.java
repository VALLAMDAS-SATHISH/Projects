package com.codeboard.codeboardaws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodeboardAwsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodeboardAwsApplication.class, args);
	}

}
