package pack2;
import pack1.*;

public class AccessSpecifiers3 extends ProaccessSpecifiers{

	public static void main(String[] args) {
		AccessSpecifiers3 obj = new AccessSpecifiers3 ();   
	       obj.display();  
	}

}
